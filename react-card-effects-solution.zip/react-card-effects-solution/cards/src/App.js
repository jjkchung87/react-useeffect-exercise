import React from 'react';
import Deck from "./Deck"

function App() {
  return (
      <div>
        <Deck />
      </div>
  );
}

export default App;
